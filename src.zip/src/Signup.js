import React from 'react';
import SimpleReactValidator from 'simple-react-validator';
import './App.css'; 

class Signup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {name: '', password: '',age: ''};
    this.validator = new SimpleReactValidator();
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({[event.target.name]: event.target.value});
    this.setState({[event.target.password]: event.target.value});
    this.setState({[event.target.age]: event.target.value});
  }

  handleSubmit(event) {
    //alert('A name was submitted: ' + this.state.name);
    localStorage.setItem('name', this.state.name);
    console.log (localStorage.name);
    localStorage.setItem('password', this.state.password);
    localStorage.setItem('age', this.state.age);
    alert("Registration completed successfully");
    window.location = '/Signin';
    //alert(localStorage.getItem('name'));
    //localStorage.getItem('name','password','age');0
  }

  render() {
    return (
      <div>
          <header>Signup Form</header>
        <label>
          <div>Name:
        <input type="text" value={this.state.name} onChange={this.handleChange} name="name" /></div>
          <div>Password:
          <input type="text" value={this.state.password} onChange={this.handleChange} name="password" /></div>
          <div>Age:
          <input type="text" value={this.state.age} onChange={this.handleChange} name="age" /></div>

        </label>
        <input type="submit" value="Submit" onClick={this.handleSubmit}/>
      </div>
    );
  }
}
export default Signup;