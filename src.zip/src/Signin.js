import React, { Component } from 'react';
import './App.css';
import SimpleReactValidator from 'simple-react-validator';
import { createHashHistory } from 'history'
export const history = createHashHistory() 

class Signin extends React.Component {
  constructor(props) {
    super(props);
    this.state = {name: '', password: ''};
    this.enter = this.enter.bind(this);
    this.validator = new SimpleReactValidator();
    this.handleChange = this.handleChange.bind(this);
    
  }

  handleChange({ target }) {
    this.setState({
      [target.name]: target.value
    });
  }



  enter() {

    var name = localStorage.getItem('name');
    var password = localStorage.getItem('password');

    if (this.validator.allValid()) 
    {
      if ( name=== this.state.name && password === this.state.password) 
      {       
         
        
        alert ("Login success"); 
        window.location = '/Home';
        // history.push('/Home');            
      } 
      else if(this.state.name !== name){
        alert ("Data Not match");         
        return false;
      }
      else{
        alert ("you enter incorrect data");         
        return false;
      }
    } }
    
  

  render() {
    return (
  
      <form onSubmit={this.handleSubmit}>
          <header>Login Form</header>
        <label>
          <div>Name:
        <input type="text" value={this.state.name} onChange={this.handleChange} name="name" /></div>
          <div>Password:
          <input type="password" value={this.state.password} onChange={this.handleChange} name="password" /></div>
        </label>
        <input type="enter" value="Submit"  onClick={ this.enter } />
      </form>
    );
  }
}
export default Signin;