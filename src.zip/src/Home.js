import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class Home extends Component {
  render() {
   var name = localStorage.getItem('name');
  //  return name;
   let str = "";
   if(name){
     str = <p>Welcome to {name} </p>;
   }else{
     str = "<p>Welcome to React App </p>";
   }
    
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
        {str}
          
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
        </header>
      </div>
    );
  }
}

export default Home;
