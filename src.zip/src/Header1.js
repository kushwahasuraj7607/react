import React from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Signup from './Signup';
import Signin from './Signin';
import Home from './Home';
import Logout from './Logout';
function Header1() {
  let log = localStorage.getItem('name');
  let menu ="";
  if(log){
    menu = <li>
    <Link to="/Logout">Logout</Link>
  </li>;
  }else{
    menu = "";
  }

  return (
    <Router>
      <div>
        <ul>
          <li>
            <Link to="/Home">Home</Link>
          </li>
          <li>
            <Link to="/Signup">Signup</Link>
          </li>
          <li>
            <Link to="/Signin">Signin</Link>
          </li>
          {menu} 
        </ul>

        <hr />

        <Route exact path="/Home" component={Home} />
        <Route path="/Signup" component={Signup} />
        <Route path="/Signin" component={Signin} />
        <Route path="/Logout" component={Logout} />
        
      </div>
    </Router>
  );
}
  
function Topics({ match }) {
  return (
    <div>
      <h2>Topics</h2>
      <ul>
        <li>
          <Link to={`${match.url}/rendering`}>Rendering with React</Link>
        </li>
        <li>
          <Link to={`${match.url}/components`}>Components</Link>
        </li>
        <li>
          <Link to={`${match.url}/props-v-state`}>Props v. State</Link>
        </li>
      </ul>

      <Route path={`${match.path}/:topicId`} component={Topic} />
      <Route
        exact
        path={match.path}
        render={() => <h3>Please select a topic.</h3>}
      />
    </div>
  );
}

function Topic({ match }) {
  return (
    <div>
      <h3>{match.params.topicId}</h3>
    </div>
  );
}

export default Header1;