import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';

class Hello extends React.Component{
  render(){
    return(
      <form>
  <label>
   Name:
  <input type="text" name="name" />
  </label>
  <input type="submit" value="Submit" />
   </form>
    )
  }
}


class Worlds extends React.Component{
  render(){
    return(
      <div>Worldsss</div>
    )
  }
}

class App extends Component {
  render() {
    return (
      <div className="App">
      <Hello />
      <Worlds />
      </div>
      );
    }
  }

export default App;
